function myservices($scope){
    $scope.services=[
        { title: ' Dell Laptop', price: 350},
        { title: 'Headphones', price: 25},
        { title: 'Apple Tabs', price: 400},
        { title: 'coffee drinking', price: 10}];
    $scope.total=function(){
        var t = 0;
        angular.forEach($scope.services, function(s){
            if(s.selected)
                t+=s.price;
        });
        return t;
    };
}